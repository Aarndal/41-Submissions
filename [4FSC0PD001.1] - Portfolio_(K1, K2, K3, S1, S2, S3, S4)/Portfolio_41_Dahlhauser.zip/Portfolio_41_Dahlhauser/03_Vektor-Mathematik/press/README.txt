Im Rahmen dieses Projektes wurde eine Vektor-Klasse erzeugt, welche verschiedene Funktionsweisen beinhaltet, die in der Vektormathematik zur Anwendung kommen.
Die Klasse umfasst dabei u. a. Standardvektoren, Einheitsvektoren, Methoden zur Addition, Subtraktion und Multiplikation von Vektoren uvm.
Außerdem wurden Eigenschaften und Logikabfragen inkludiert, welche in der Vektormathematik gebräuchlich sind.
Ziel war es, eine für den 2- und 3-dimensionalen Raum mit rechtshändigen, kartesischem Koordinatensystem geeignete Vektor-Klasse zu erzeugen, die allgemein anwendbar ist.

Eine Ausgabe der einzelnen Methoden war nicht Teil der Aufgabenstellung und wurde von daher auch nicht vorgenommen.

