In dem Projekt "Escape Room" wird unter Zuhilfenahme eines 2D-Arrays ein rechteckiger Raum erstellt, in welchem eine Spielfigur sich bewegen, einen Schlüssel einsammeln und damit eine Tür öffnen kann. 
Die Spielmechanik sowie die Steuerung werden zu Beginn erklärt und die Länge sowie Breite des Raumes müssen von der spielenden Person festgelegt werden. 
Die Spielfigur und der Schlüssel werden zufällig im Raum platziert, während die Tür an einer zufälligen Position an einer der Wände positiniert wird. 
Die Spielfigur kann mit den Pfeiltasten oder WASD bewegt werden, wobei Kollisionen mit Wänden und der verschlossenen Tür berücksichtigt werden. 
Durch Einsammeln des Schlüssels und Betreten der Tür kann die Tür aufgeschlossen und das Spiel gewonnen werden.

// Ausführung der exe-Datei
Damit das Programm ausgeführt werden kann, muss .NET Desktop Runtime 6.0.26 oder höher installiert sein.