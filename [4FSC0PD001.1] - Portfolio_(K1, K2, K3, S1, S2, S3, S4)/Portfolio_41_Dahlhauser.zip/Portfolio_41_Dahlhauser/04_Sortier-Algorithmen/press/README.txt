In diesem Porjket bestand die Aufgabe darin, innerhalb der Laufzeit des Programms eine Reihe von Zahlen mit Hilfe von verschiedenen Sortieralgorithmen auf eine von drei Weisen sortieren zu lassen.
Zu Beginn kann der Benutzer entweder eine bestimmte Anzahl zufälliger Zahlen generieren lassen oder selbst eine Reihe von Zahlen eingeben.
Anschließend werden die Zahlen mit einem Sortieralgorithmus, welchen der User auswählt, sortiert.
Die sortierte Reihe kann dann in aufsteigender, absteigender oder zickzack Form (zuerst die größte Zahl, dann die kleinste Zahl, dann die zweit größte und dann die zweit kleinste, usw.) ausgegeben werden.

// Ausführung der exe-Datei
Damit das Programm ausgeführt werden kann, muss .NET Desktop Runtime 6.0.26 oder höher installiert sein.